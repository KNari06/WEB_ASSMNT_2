require('dotenv').config();
const express = require('express');

const app = express();
app.use(express.static('public'));

app.get('/api/user', async (req, res) => {
  try {
    // 1️⃣ RANDOM USER
    const userResponse = await fetch('https://randomuser.me/api/');
    const userData = await userResponse.json();
    const user = userData.results[0];

    const firstName = user.name.first;
    const lastName = user.name.last;
    const gender = user.gender;
    const age = user.dob.age;
    const dob = user.dob.date;
    const picture = user.picture.large;
    const city = user.location.city;
    const country = user.location.country;
    const address = `${user.location.street.name} ${user.location.street.number}`;

    // 2️⃣ COUNTRY INFO
    const countryResponse = await fetch(
      `https://restcountries.com/v3.1/name/${encodeURIComponent(country)}`
    );
    const countryData = await countryResponse.json();
    const countryInfo = countryData[0];

    const capital = countryInfo.capital?.[0] || 'N/A';
    const languages = countryInfo.languages
      ? Object.values(countryInfo.languages).join(', ')
      : 'N/A';

    const currencyCode = countryInfo.currencies
      ? Object.keys(countryInfo.currencies)[0]
      : 'N/A';

    const currencyName =
      currencyCode !== 'N/A'
        ? countryInfo.currencies[currencyCode].name
        : 'N/A';

    const flag = countryInfo.flags?.svg || '';

    // 3️⃣ EXCHANGE RATE (GRACEFUL)
    let usdRate = 'N/A';
    let kztRate = 'N/A';

    if (currencyCode !== 'N/A') {
      try {
        const rateResponse = await fetch(
          `https://v6.exchangerate-api.com/v6/${process.env.EXCHANGE_API_KEY}/latest/${currencyCode}`
        );

        if (rateResponse.ok) {
          const rateData = await rateResponse.json();
          usdRate = rateData.conversion_rates?.USD || 'N/A';
          kztRate = rateData.conversion_rates?.KZT || 'N/A';
        }
      } catch {

      }
    }

    // 4️⃣ NEWS
    let news = [];

    try {
      const newsResponse = await fetch(
        `https://newsapi.org/v2/top-headlines?q=${encodeURIComponent(
          country
        )}&language=en&pageSize=5&apiKey=${process.env.NEWS_API_KEY}`
      );

      if (newsResponse.ok) {
        const newsData = await newsResponse.json();
        news = newsData.articles.map(article => ({
          title: article.title,
          description: article.description,
          image: article.urlToImage,
          url: article.url
        }));
      }
    } catch {
      news = [];
    }

    // SEND DATA
    res.json({
      user: {
        firstName,
        lastName,
        gender,
        age,
        dob,
        picture,
        city,
        country,
        address
      },
      country: {
        name: country,
        capital,
        languages,
        currency: currencyName,
        flag
      },
      exchangeRates: {
        USD: usdRate,
        KZT: kztRate
      },
      news
    });

  } catch (error) {
    console.error('SERVER ERROR:', error.message);
    res.status(500).json({ error: error.message });
  }
});

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
