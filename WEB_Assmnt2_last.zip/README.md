# Assignment 2 — API Integration Project

## Student: Nariman Kaidar

## Course: Web Technologies 2

## Server: Node.js + Express

## Port: 3000

---

## 📌 Project Objective

The objective of this project is to learn how to work with **APIs on the server side**, retrieve, process, and display data in a **frontend application**. The project demonstrates integration of multiple APIs using **Node.js and Express**, following clean code and best practices.

---

## Project Overview

This application:

* Fetches a **random user** from an external API
* Retrieves **country information** based on the user’s country
* Shows **exchange rates** for the user’s currency
* Displays **news headlines** related to the user’s country

All API logic is implemented **only on the server side**. The frontend only displays processed data received from the server in **JSON format**.

---

## Technologies Used

* Node.js
* Express.js
* Fetch API (built-in in Node.js 18+)
* dotenv
* HTML / CSS (Frontend)

---

##  APIs Used

### 1 Random User Generator API

**URL:** [https://randomuser.me/api/](https://randomuser.me/api/)

Used to retrieve:

* First name
* Last name
* Gender
* Profile picture
* Age
* Date of birth
* City
* Country
* Full address

---

### 2 REST Countries API

**URL:** [https://restcountries.com/](https://restcountries.com/)

Used to retrieve:

* Country name
* Capital city
* Official language(s)
* Currency
* National flag

---

### 3 Exchange Rate API

**URL:** [https://www.exchangerate-api.com/](https://www.exchangerate-api.com/)

Used to compare the local currency with:

* USD (United States Dollar)
* KZT (Kazakhstani Tenge)

If the API is unavailable, the application handles it gracefully.

---

### 4 News API

**URL:** [https://newsapi.org/](https://newsapi.org/)

Used to retrieve:

* Five news headlines in English
* Related to the user’s country
* Title, image, description, and source URL

---

## Project Structure

```
WEB_Assmnt2/
│
├── server.js          # Core backend logic
├── package.json       # Project dependencies
├── .env               # API keys (not shared)
└── public/
    └── index.html     # Frontend display only
```

---

## Environment Variables

API keys are stored securely using environment variables:

```
EXCHANGE_API_KEY=your_exchange_api_key
NEWS_API_KEY=your_news_api_key
```

This ensures security and prevents exposing sensitive information.

---

## How to Run the Project

1. Install dependencies:

```bash
npm install
```

2. Start the server:

```bash
node server.js
```

3. Open in browser:

```
http://localhost:3000
```

---

## Frontend Description

The frontend:

* Contains a button **Get Random User**
* Sends a request to `/api/user`
* Receives processed JSON data
* Displays data using cards and structured sections

No business logic or API calls are implemented in HTML.

---

## Server-Side Logic

All API calls and data processing are handled in **server.js**:

* Fetching data from APIs
* Parsing responses
* Error handling
* Sending clean JSON to frontend

This follows best practices for security and maintainability.

---

## Error Handling

The application implements **graceful error handling**:

* If an API is unavailable, the application continues to work
* Missing data is replaced with `N/A`
* The server never crashes due to external API issues

---

## Key Design Decisions

* Server-side API handling for security
* JSON used for data exchange
* Clean separation between backend and frontend
* Graceful handling of unavailable APIs

---

## Conclusion

This project demonstrates practical usage of server-side APIs using Node.js and Express. It follows clean code principles, ensures secure API handling, and provides a responsive and user-friendly interface.

---

## Ready for Defense

This project fully meets the Assignment 2 requirements and is ready for presentation and defense.
